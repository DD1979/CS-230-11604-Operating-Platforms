//  ============================================================================  //
//  Name        :  Project 1  //
//  Author      :  David A. DiPesa  //
//  Description :  Project 1 / The "Revised Game Class  //
//  Instructor  :  Alexander Dubinski (Alex)  //
//  Class       :  CS-230-11604-M01:  Operating Platforms  //
//  ============================================================================  //

package com.gamingroom;  //  We need the Gaming Room for this  //

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;  //  Need to use iterator here per our assignment //

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 *
 */
 
public class Game extends Entity {  //  We now need to inherit from "Entity" to run Game  //
//  Deleting long id and String name for this to work...  //

	private static List<Team> teams = new ArrayList<Team>();  //  For a list of active teams in the game  //

	//  Public constructor with an identifier and name  //

	public Game(long id, String name) {
		super(id, name);
	}

	/**
	 * We'll use the iterator pattern so we can find any
	   existing teams with the same name in this program.
	   We want to create unique teams and add to the list.  */
	 
public Team addTeam(String name) {

        //  Local team instance here  //
        Team team = null;  //  Let's start with null  //

        //  Our Instance iterator  //
        Iterator<Team> teamsIterator = teams.iterator();

        //  While:  Iterate over teams list  //
        while (teamsIterator.hasNext()) {

        //  Set local Team variable to next item in list  //
            Team teamInstance = teamsIterator.next();

        //  If:  Does team name already exist?  //
            if (teamInstance.getName().equalsIgnoreCase(name)) {
                // If team name already exists, return the team instance
                team = teamInstance;
            } else {
        // Else:  Add the team to the teams list  //
                teams.add(team);
            }  //  End If / Else  //
        }

        return team;
	}

	@Override
	public String toString() {
		return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
	}

}  //  Let's End Game //