//  ============================================================================  //
//  Name        :  Project 1  //
//  Author      :  David A. DiPesa  //
//  Description :  Project 1 / The "Revised" Team Class  //
//  Instructor  :  Alexander Dubinski (Alex)  //
//  Class       :  CS-230-11604-M01:  Operating Platforms  //
//  ============================================================================  //

package com.gamingroom;  //  We need the Gaming Room for this  //

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 *
 */
public class Team extends Entity {  //  Need to derive from the "Entity" now to run Team  //
//  Delete long id and String name to complete now  //
	
private List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

/**
	 * Construct a new player instance
	 * 
	 * @param name the unique name of the player
	 * @return the player instance (new or existing)
	 */
	public Player addPlayer(String name) {

		//  This is a local Player instance  //
		Player player = null;  //  Set to null for now  //

		/*  For Loop:  Iterate over players to look for existing with the same
		    name and if found, return the existing instance  */
		for (int i = 0; i < players.size() - 1; i++) {
	    //  Iterate through players list to see if chosen name already exists  //
			if (players.get(i).getName() == name) {
				player = players.get(i);
			}
		}  //  End For Loop  //
		
		//  If: Name not found: Create new instance and add to list of teams   //
		if (player == null) {  //  Null == does not exist!!  //
		//  Get a reference to the GameService singleton instance  //
			GameService service = GameService.getInstance();
			
		//  Use GameService reference to call the getNextPlayerId() to get the ID to designate the new player  //
			player = new Player(service.getNextPlayerId(), name, null);
			players.add(player);  //  adding per assignment  //
		}  //  End If  //

		//  Return the new / existing game instance to the caller  //
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}  //  Let's End Team  //