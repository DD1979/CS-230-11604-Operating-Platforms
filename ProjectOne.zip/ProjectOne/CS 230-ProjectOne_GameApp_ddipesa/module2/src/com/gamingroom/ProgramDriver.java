package com.gamingroom;  //  Added the path  //

/**
 * Application start-up program */
 
public class ProgramDriver {  //  Let's Drive!!!  //
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
/**  Added the Singleton GameService instance here,
	 Only one instance runs across this application thanks to using Singleton Design  **/
		GameService service = GameService.getInstance();  //  Replaced "null" with GameService.getInstance()  //
		
		System.out.println("\nReady to commence with testing the game data…\n");
		
		//  Initialize with some game data  //
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
		//  Use another class to prove there is only one instance  //
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}  //  End Class  //

//  Quick Notes: Line 17 issues addressed per milestone assignment. //
