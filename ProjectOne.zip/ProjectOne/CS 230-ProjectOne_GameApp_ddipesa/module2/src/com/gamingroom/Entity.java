//  ============================================================================  //
//  Name        :  Project 1  //
//  Author      :  David A. DiPesa  //
//  Description :  Project 1 / The "New" Entity Base Class  //
//  Instructor  :  Alexander Dubinski (Alex)  //
//  Class       :  CS-230-11604-M01:  Operating Platforms  //
//  ============================================================================  //


package com.gamingroom; //  We need the Gaming Room for this //

/**
 * This is a base class to hold the required attributes for our child classes per this assignment.
 **/
 
public class Entity { //  Creating Entity for our assignment  //
	
//  All Entities will have have a unique ID and a Name for the game  //
	protected long id;
	protected String name;

//  Default constructor is protected to allow only our child classes to view the constructor  //
	protected Entity() {}
	
//  Public information == id and a name  //
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}

//  Here's a method to return the id  //
	public long getId() {
		return id;
	}  //  Return the ID  //
	
//  Now a method to return the name  //
	public String getName() {
		return name;
	}  //  Return the name  //
	
	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}  //  Let's End Entity  //