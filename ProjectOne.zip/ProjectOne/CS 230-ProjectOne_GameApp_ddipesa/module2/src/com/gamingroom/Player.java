//  ============================================================================  //
//  Name        :  Project 1  //
//  Author      :  David A. DiPesa  //
//  Description :  Project 1 / The "Revised" Player Class  //
//  Instructor  :  Alexander Dubinski (Alex)  //
//  Class       :  CS-230-11604-M01:  Operating Platforms  //
//  ============================================================================  //

package com.gamingroom;  //  We need the Gaming Room for this  //

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 *
 */
public class Player extends Entity {  //  Need to derive this from the "Entity" now to run Player  //
//  Delete the long id and String name to complete now  //
	

//  Constructor with an identifier, name and a team  //

	public Player(long id, String name, Team team) {
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + "]";
	}
}  //  Let's End Player  //
