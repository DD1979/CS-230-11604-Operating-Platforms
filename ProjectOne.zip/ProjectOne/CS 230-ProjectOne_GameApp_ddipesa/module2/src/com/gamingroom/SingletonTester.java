package com.gamingroom;

/**
 * A class to test a singleton's behavior
 */
public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nReady to test the singleton...");
		
//  Addressing the FIXME per this assignment:  obtain local reference to the singleton instance  //
		//  No more null !!!  //
		GameService service = GameService.getInstance();  // replaced null with GameService.getInstance  //
		
		//  Adding a simple for loop to print the games  //
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}  //  End Loop  //

	}
	
}  //  End Class  //


// Quick Notes: Line 14 issues addressed. //