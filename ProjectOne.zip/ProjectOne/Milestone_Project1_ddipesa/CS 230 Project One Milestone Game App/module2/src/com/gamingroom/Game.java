//  ============================================================================  //
//  Name        :  Project 1  //
//  Author      :  David A. DiPesa  //
//  Description :  Project 1 / The "Revised Game Class  //
//  Instructor  :  Alexander Dubinski (Alex)  //
//  Class       :  CS-230-11604-M01:  Operating Platforms  //
//  ============================================================================  //

package com.gamingroom;  //  We need the Gaming Room for this  //

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;  //  Need to use iterator here per our assignment //

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 *
 */
 
public class Game extends Entity {  //  We now need to inhert from "Entity" to run Game  //
//  Deleting long id and String name for this to work...  //

	private static List<Team> teams = new ArrayList<Team>();  //  For a list of active teams in the game  //

	//  Public constructor with an identifier and name  //

	public Game(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * We'll use the iterator pattern so we can find any
	   existing teams with the same name in this program.
	   We want to create unique teams and add to the list.  */
	 
public Team addTeam(String name) {

        //  Local team instance here  //
        Team team = null;  //  Let's start with null  //

        /*  For Loop:  Iterate over Teams to look for existing with the same
		    name and if found, return the existing instance  */
		for (int i = 0; i < teams.size() - 1; i++) {
		//  looks through teams list to see if name exists
			if (teams.get(i).getName() == name) {
				team = teams.get(i);
			}
		}  //  End For Loop  //
		
		//  If: Name not found: Create new instance and add to list of teams   //
		if (team == null) {  //  Let's start with null  //
			GameService service = GameService.getInstance();
			
		//  Use GameService reference to call the getNextPlayerId() to get the ID to designate the player  //
			team = new Team(service.getNextPlayerId(), name);
			teams.add(team);  //  adding per assignment  //
		}  //  End If  //

		//  Return the new / existing game instance  //
		return team;
	}

	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}
	
}  //  Let's End Game  //