package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator; //  Added Iterator for this class assignment  //

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

//  Adding my code here to turn this into a singleton design per assignment //
	
	//  Creating a private variable to track the existence of GameService  //
    private static GameService service = null; //  setting the intial value to null  //

    //  Behold the Constructor  //
    private GameService() {
    }
    
    /**
     //  Here we check for an existing instance of GameService  //
     * @return
     */
	public static GameService getInstance() {

        //  If / Else:  Does GameService exist?  //
	    if (service == null) {  //  if null  //
            //  If not, create a new game instance  //
	        service = new GameService();
	        System.out.println("A New Game Service has been created (manifested).");  //  printed for you  //
        } else { 
            //  If one already exists, a message to you and you and me  //
            System.out.println("A Game Service has already been instantiated.");  //  printed for you  //
        }  //  End IF / Else //

        //  Return new or existing, but only the single instance can run  //
        return service;
    }
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {  

		// a local game instance
		Game game = null;

        //  Added an instance iterator of type Game  //
        Iterator<Game> gamesIterator = games.iterator();

        //  While to Iterate over our list of games  //
        while (gamesIterator.hasNext()) {

            //  Set a local Game to next item in list  //
            Game gameInstance = gamesIterator.next();

            //  If Statement:  Does a game name already exist?  //
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                //  If: Game name already exists / return the instance  //
                return gameInstance;
            } //  end IF  //
        }  //  end While  //

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		//  Return the new / existing game instance to the caller  //
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		//  Using my Instance iterator here per the assignment  //
        Iterator <Game> gamesIterator = games.iterator();

        //  While: Iterate over the list of games  //
        while (gamesIterator.hasNext()) {

            //  Set local Game variable as the next item in list  //
            Game gameInstance = gamesIterator.next();

            //  If: Does a game id already exist?  //
            if (gameInstance.getId() == id) {
                //  If game id already exists / return that game instance  //
                return gameInstance;
            }  //  End If  //
        }  //  End While  //

		return game;  //  return the game  //
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

	    //  Using my Instance iterator here per the assignment  //
        Iterator<Game> gamesIterator = games.iterator();

        //  While: Iterate over the list of games  //
        while (gamesIterator.hasNext()) {

            //  Set local Game variable as the next item in list  //
            Game gameInstance = gamesIterator.next();

            //  If State: Does a game id already exist?  //
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                //  If game id already exists / return that game instance  //
                game = gameInstance;
            }  //  End If  //
        }  //  End WHile  //

		return game;  //  return the game  //
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}  //  End Public Class GameService  //

/*  Quick Notes:  Only items were addressed from the FIXME comments  
 *                Lines 23, 54, 85 and 121 per assingment  /*
