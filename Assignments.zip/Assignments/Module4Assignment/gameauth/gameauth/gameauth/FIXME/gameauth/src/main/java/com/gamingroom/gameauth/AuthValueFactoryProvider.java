package com.gamingroom.gameauth;

public class AuthValueFactoryProvider {

}
