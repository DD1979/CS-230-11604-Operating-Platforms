package com.fasterxml.jackson.annotation;

public class JsonProperty {

}
