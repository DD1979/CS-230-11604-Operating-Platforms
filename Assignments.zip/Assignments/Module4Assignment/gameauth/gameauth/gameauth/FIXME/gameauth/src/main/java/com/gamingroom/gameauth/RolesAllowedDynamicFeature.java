package com.gamingroom.gameauth;

public class RolesAllowedDynamicFeature {

}
