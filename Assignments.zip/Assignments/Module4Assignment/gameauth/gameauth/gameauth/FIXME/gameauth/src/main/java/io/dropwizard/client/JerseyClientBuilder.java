package io.dropwizard.client;

public class JerseyClientBuilder {

}
