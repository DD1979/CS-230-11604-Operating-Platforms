package io.dropwizard;

public class Configuration {

}
